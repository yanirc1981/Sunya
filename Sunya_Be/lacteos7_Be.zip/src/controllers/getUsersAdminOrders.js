const { Order } = require('../data');

const response = require('../utils/response');

module.exports = async (req, res) => {
    const orders = await Order.findAll();
  
      if (orders.length === 0) {
        return response(res, 404, { message: 'No se encontraron reservas.' });
      }
  
      return response(res, 200, orders );
};

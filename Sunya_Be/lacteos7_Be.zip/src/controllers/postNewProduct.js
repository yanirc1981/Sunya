const { Product } = require('../data');
const response = require('../utils/response');

module.exports = async (req, res) => {
  const product = req.body;

  await Product.create({
    name: product.name,
    slug: product.slug,
    image: product.image,
    brand: product.brand,
    description: product.description,
    price: product.price,
    countInStock: product.countInStock,
    rating: product.rating,
    numReviews: product.numReviews,
  });
  response(res, 201, 'success');
};

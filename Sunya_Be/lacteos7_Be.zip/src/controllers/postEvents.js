const { Order } = require('../data');
const crypto = require('crypto');
const response = require('../utils/response');
const { EVENTS_SECRET_KEY } = require('../config/envs');

module.exports = async (req, res) => {
  const { event, data, environment, signature, timestamp } = req.body;
  console.log(data);
  const WompiSecret = EVENTS_SECRET_KEY;
  // Paso 1: Concatenar los valores de las propiedades
  const properties = signature.properties
    .map((prop) => {
      return prop.split('.').reduce((o, i) => o[i], data);
    })
    .join('');

  // Paso 2: Concatenar el timestamp
  const concatenatedString = properties + timestamp;

  // Paso 3: Concatenar tu secreto
  const stringToHash = concatenatedString + WompiSecret;

  // Paso 4: Generar el checksum usando SHA256
  const generatedChecksum = crypto
    .createHash('sha256')
    .update(stringToHash)
    .digest('hex');

  // Paso 5: Comparar el checksum generado con el proporcionado por Wompi
  if (generatedChecksum !== signature.checksum) {
    return res.status(400).send('Invalid checksum');
  }

  //obtener el id de la orden 

const addressLine2 = data.transaction.shipping_address.address_line_2;
const regex = /Oficina (\d+)/;
const match = addressLine2.match(regex);
let orderId = null;

if (match && match[1]) {
  orderId = parseInt(match[1], 10);
} else {
  console.error('No se encontró un número después de "Oficina" en address_line_2');
}

  
  // Procesar el evento
  if (event === 'transaction.updated') {
    try {
      // Buscar la orden por ID
      const order = await Order.findOne({ where: { id: orderId } });
      if (order) {
        // Actualizar el campo paymentResult
        order.paymentResult = data;
        order.paidAt = data.transaction.finalized_at;
        order.isPaid = true;
        await order.save();
      } else {
        return res.status(404).send('Order not found');
      }
    } catch (error) {
      console.error('Error updating order:', error);
      return res.status(500).send('Internal Server Error');
    }
  }

  
    return response(res, 200, 'success');
 
};

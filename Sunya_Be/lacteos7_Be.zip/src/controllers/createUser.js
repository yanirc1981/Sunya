const { User } = require("../data");
const response = require("../utils/response");
const bcrypt = require("bcrypt");

module.exports = async (req, res) => {

  const user = req.body;


  // encriptar password
  hash = await bcrypt.hash(user.password, 10);

  await User.create({
    first_name: user.first_name,
    last_name: user.last_name,
    gender: user.gender[0],
    n_document: user.n_document,
    email: user.email,
    password: hash,
    phone: user.phone,
    city: user.city,
    id_role: user.id_role 
  });
  response(res, 201, "success");
};

module.exports = {
  chargeRol: require('./chargeRol'),
  chargeUsers: require('./chargeUsers'),
  chargeProduct: require('./chargeProduct'),
  chargeStore: require('./chargeStore'),
  chargePartner: require('./chargePartner'),
};

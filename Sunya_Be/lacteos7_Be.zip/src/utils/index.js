module.exports = {
  response: require('./response'),
  catchedAsync: require('./catchedAsync'),
  isAuth: require('./isAuth'),
  isAdmin: require('./isAdmin'),
};
